import { ResultMessage } from "./completion_types";

import ollama, { ChatResponse } from 'ollama'


export type OllamaResponse = AsyncGenerator<ChatResponse, unknown, unknown>;



/*
 Select the model
 gemma and llama2 are big models
*/
type Model = "phi:chat" | "tinyllama:chat" | "llama2:chat" | "gemma:2b-text" | "mistral";

const MODEL_NAME: Model = "mistral";

export const getChatCompletionStream = async (messages: ResultMessage[]): Promise<OllamaResponse> => {
    const response = await ollama.chat({
        model: MODEL_NAME,
        messages: messages,
        stream: true,
        options: {
            temperature: 0.2,
            top_p: 0.4,
            stop: ["["]
        }
    })
    return response;
}

export const getChatCompletion = async (messages: ResultMessage[]): Promise<ChatResponse> => {
    const response = await ollama.chat({
        model: MODEL_NAME,
        messages: messages,
        stream: false,
        options: {
            temperature: 0.2,
            top_p: 0.4,
            stop: ["$STOP$"]
        }
    })
    return response;
}
